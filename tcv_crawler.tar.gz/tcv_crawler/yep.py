import json

results = []
with open('Doctor-rev3.json', 'r') as f:
    content = json.loads(f.read())
    for element in content:
        results.append(','.join([str(y[1]) for y in element['points']]))

with open('trial_3.csv', 'w') as f:
    f.write('\n'.join(results))
