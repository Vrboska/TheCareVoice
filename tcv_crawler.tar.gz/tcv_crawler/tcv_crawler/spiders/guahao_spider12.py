### Scrapy spider to crawl Shanghai hospital reviews from guahao.com (by Andrej Zubal) (funguje!)
import scrapy
import logging
import time
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from tcv_crawler.items import  HospitalReviewItem, HospitalItem

############## this part of code is only for making selenium run with firefox on my computer
"""
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities

caps = DesiredCapabilities.FIREFOX
caps["marionette"] = True
caps["binary"] = "/usr/bin/firefox"
"""
#############################################################################################

class GuahaoSpider(scrapy.Spider):
    name = "guahao12"
    allowed_domains = ["www.guahao.com"]

    start_urls = (
        "http://www.guahao.com/hospital/areahospitals?pi=2&p=%E4%B8%8A%E6%B5%B7",
    )

    def __init__(self):
        
        self.driver = webdriver.PhantomJS()#Chrome('/usr/lib/chromium-browser/chromedriver')#
        self.login="13524005993"
        self.password="Zdravie"
        self.num_pages=2   #number of pages to crawl  in total (i.e. for Shanghai there are 30 pages)
        self.pageNo=1       #current page the spider is on
        self.total=0

    def parse(self, response):
        """
        ###Logging in part
        
        self.driver.get('http://www.guahao.com/user/login?target=%2Fhospital%2Fareahospitals%3Fpi%3D2%26p%3D%25E4%25B8%258A%25E6%25B5%25B')
        self.driver.find_element_by_id("loginId").send_keys(self.login)
        self.driver.find_element_by_id("password").send_keys(self.password)
        self.driver.find_element_by_id("validCode").send_keys(raw_input("Please enter the expression on the picture: "))
        self.driver.find_element_by_id("J_LoginSubmit").click()

        """
        ### Crawling part
        
        self.driver.get(response.url)
        
        while self.pageNo<=self.num_pages:
            print self.pageNo
            url=self.driver.current_url
            request = scrapy.Request(url, callback=self.hospitals_page)
            yield request
            if(self.pageNo<self.num_pages):

                elem=self.driver.find_element_by_xpath("//div[@class='pagers']/a[@class='next J_pageNext_gh']")

                if (elem.is_displayed()==True and elem.is_enabled()==True):
                    try:
                        elem.click()
                        time.sleep(5)
                        #WebDriverWait(self.driver, 20).until(EC.presence_of_element_located(self.driver.find_element_by_xpath("//div[@class='pagers']/a[@class='next J_pageNext_gh']")))
                    except:
                        print "The next page was clicked unsuccessfully!"
                        return
                else:
                     print "Next page is either disabled or not displayed"
                     return
            self.pageNo +=1
        """
        ###Logging out part
        try:
            self.driver.find_element_by_xpath("//*[@id='gh']/div[1]/div/div[1]/a[4]").click()
            print "Logged out successfully!"
        except:
            print "Could not log out!"
        """      
        self.driver.quit()




    def hospitals_page(self, response):
        urls = response.xpath("//div[@id='g-cfg']//ul[@class='hos_ul']//a[@class='cover-bg']/@href").extract()

        for url in urls:
            hospitalID = url.strip("http://www.guahao.com/hospital/")
            print "\n This hospital's id is " + hospitalID+"\n"
            
            request = scrapy.Request(url, callback=self.hospital_page)
            request.meta['hospitalID'] = hospitalID
            yield request
            
            
    def hospital_page(self, response):      
        review_url=response.xpath("//div[@class='more']/a/@href").extract()[0]
        if review_url:
            request = scrapy.Request(review_url, callback=self.review_page)
            request.meta['hospitalID'] = response.meta['hospitalID']
            yield request
        else:
            print "No reviews!"
            
            return
        
        
    def review_page(self, response):
        self.total+=1
        print self.total
        return
    
            
            
            
            
            
            
            
            
            
            
            
               
    
        
        
