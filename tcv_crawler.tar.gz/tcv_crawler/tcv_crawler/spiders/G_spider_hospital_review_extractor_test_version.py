### Scrapy spider to crawl Shanghai hospitas and extract their info from guahao.com (by Andrej Zubal) (funguje!)
import scrapy
import time
import pickle
from scrapy.loader import ItemLoader
from tcv_crawler.items import HospitalReviewItem


class GuahaoSpider(scrapy.Spider):
    name = "guahaoHospRev"
    allowed_domains = ["www.guahao.com"]

    start_urls = pickle.load( open( "A.p", "rb" ) )[0:3]
    
    total=0                                                #just an auxiliary variable counting the total number of pages crawled


    def parse(self, response):
        print response.url[37:][:-4]
        
        
        
        hospital_name=response.xpath("//div[@class='detail word-break']/h1/strong/a/text()").extract_first()
        hospitalID=response.url[37:][:-4]
        
        reviewers=response.xpath("//ul[@class='word-wrap list']/li/div[@class='user']/p/text()").extract()
        reviewers=map(lambda x: x.strip('        \r\n\t'), reviewers)
        
        texts= response.xpath("//ul[@class='word-wrap list']/li/div[@class='row-2']/div[@class='text']/span[@class='summary']/text()").extract()
        
        times=map(lambda x: x[:19],(response.xpath("//ul[@class='word-wrap list']/li/div[@class='row-2']/div[@class='info']/p/span[1]/text()").extract()))

        
        diseases= response.xpath("//ul[@class='word-wrap list']/li/div[@class='row-1']/p[@class='disease']/span[1]/text()").extract()

        
        satisfactions=response.xpath("//ul[@class='word-wrap list']/li/div[@class='row-1']/p[@class='effect']/strong[1]/text()").extract()
        satisfactions=map(lambda x: x.strip('        \r\n\t'), satisfactions)

        
        doctorIDs=map(lambda x: x[29:], response.xpath("//ul[@class='word-wrap list']/li/div[@class='row-2']/div[@class='info']/p[1]/span[2]/a/@href").extract())
        
        for i in range(len(reviewers)):
            l = ItemLoader(item=HospitalReviewItem(), response=response)
            l.add_value('hospital_name', hospital_name)
            l.add_value('hospitalID', hospitalID)
            l.add_value('reviewer', reviewers[i-1])
            l.add_value('text', texts[i-1])
            l.add_value('time', times[i-1])
            l.add_value('disease', diseases[i-1])
            l.add_value('satisfaction', satisfactions[i-1])
            l.add_value('doctorID', doctorIDs[i-1])

            yield l.load_item()
            self.total+=1
            print self.total
            

        
        """
        ID=response.url[37:][:-4]
        if ID:
            l.add_value('hospitalID', ID)
        else:
            self.log("bad times :(, could not find hospitalID")

                
        name=response.xpath("//div[@class='detail word-break']/h1/strong/a/text()").extract_first()
        if name:
            l.add_value('hospital_name', name)
        else: 
            self.log("bad times :(, could not find hospital_name")
        
        
        name=response.xpath("//div[@class='detail word-break']/h1/strong/a/text()").extract_first()
        if name:
            l.add_value('name', name)
        else: 
            self.log("bad times :(, could not find name")
            
            
        description=response.xpath("//div[@class='about']/span/text()").extract_first()
        if description:
            l.add_value('description', description)
            l.add_xpath('description', "//div[@class='about']/span/a/@href")
        else: 
            self.log("bad times :(, could not find description")
            
            
        address= response.xpath("//div[@class='address']/span/@title").extract_first()
        if address:
            l.add_value('address', address)
        else:
            self.log("bad times :(, could not find address")
 
        website= response.xpath("//div[@class='website']/span/text()").extract_first()
        if website:
            l.add_value('website', website[1:])
        else:
            print("bad times :(, could not find website")
          
          
        phone= response.xpath("//div[@class='tel']/span/text()").extract_first()
        if phone:
            l.add_value('phone', phone.strip('\r\n         '))
        else:
            print("bad times :(, could not find phone")
        
        
        level= response.xpath("//div[@class='detail word-break']/h1/span[1]/text()").extract_first()
        if level:
            l.add_value('level', level.strip('\r\n                  '))
        else:
            print("bad times :(, could not find level")
            
        
 
        yield l.load_item()
        self.total+=1
        print "Hospital "+response.url+" is done!"
        print self.total
        """



   
            
            
    
        
        
