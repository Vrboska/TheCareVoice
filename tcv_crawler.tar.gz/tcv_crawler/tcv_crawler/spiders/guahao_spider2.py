# -*- coding: utf-8 -*-
#spider for crawling hospital reviews
import scrapy
import logging
import webbrowser
from tcv_crawler.items import HospitalItem, HospitalReviewItem

class GuahaoSpider(scrapy.Spider):
    name = "guahao2"
    allowed_domains = ["www.guahao.com"]
    start_urls = (
        "http://www.guahao.com/hospital/areahospitals?pi=2&p=%E4%B8%8A%E6%B5%B7",
    )

    def parse(self, response):
        urls = response.xpath("//div[@id='g-cfg']//ul[@class='hos_ul']//a[@class='cover-bg']/@href").extract()
        #print("urls is", urls)
        for url in urls:
            request = scrapy.Request(url, callback=self.hospital_page)
            yield request
        

    def hospital_page(self, response):
        hospitalID = response.xpath("//head//meta[@name='adsKeywords']//@content").extract()[0].strip("hid:")
        print "\n This hospital's id is " + hospitalID+"\n"
        
       
        
        
                  

  


