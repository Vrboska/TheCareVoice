import scrapy
import logging
import time
from tcv_crawler.items import HospitalItem, HospitalReviewItem
from selenium import webdriver

############## this part of code is only for making selenium run with firefox on my computer
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities

caps = DesiredCapabilities.FIREFOX

# Tell the Python bindings to use Marionette.
# This will not be necessary in the future,
# when Selenium will auto-detect what remote end
# it is talking to.
caps["marionette"] = True

# Path to Firefox DevEdition or Nightly.
# Firefox 47 (stable) is currently not supported,
# and may give you a suboptimal experience.
#
# On Mac OS you must point to the binary executable
# inside the application package, such as
# /Applications/FirefoxNightly.app/Contents/MacOS/firefox-bin
caps["binary"] = "/usr/bin/firefox"
#############################################################################################

class GuahaoSpider(scrapy.Spider):
    name = "guahao5"
    allowed_domains = ["www.guahao.com"]
    start_urls = (
        "http://www.guahao.com/hospital/areahospitals?pi=2&p=%E4%B8%8A%E6%B5%B7",
    )

    def __init__(self):
        self.driver = webdriver.Firefox()#this is the selenium driver i.e. opens a browser (used to access "next" pages)
        self.pageNo=1


    def parse(self, response):
        self.driver.get(response.url)#opening the initial page in browser
        
        while self.pageNo<=3:### looping through a preset number of pages

            print self.driver.current_url
            url=self.driver.current_url
            request = scrapy.Request(url, callback=self.hospital_page)
            yield request
            
            elem=self.driver.find_element_by_xpath("//div[@class='pagers']/a[@class='next J_pageNext_gh']")
        
            if (elem.is_displayed()==True and elem.is_enabled()==True):
        
                try:
                    elem.click()
                    time.sleep(5)
                except:
                    print "The next page was clicked unsuccessfully!"
                    return
            else:
                 print "Next page is either disabled or not displayed"
                 return
            self.pageNo +=1

        self.driver.close()

        
    def hospital_page(self, response):
        urls = response.xpath("//div[@id='g-cfg']//ul[@class='hos_ul']//a[@class='cover-bg']/@href").extract()
        print("urls is", urls)
        for url in urls:
            request = scrapy.Request(url, callback=self.hospital_id)
            yield request

            
    def hospital_id(self, response):
        hospitalID = response.url.strip("http://www.guahao.com/hospital/")
        print "\n This hospital's id is " + hospitalID+"\n"

        
        
