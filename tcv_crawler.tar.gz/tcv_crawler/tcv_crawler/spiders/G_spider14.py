import scrapy
import logging
import time
import pickle
from scrapy.xlib.pydispatch import dispatcher
from scrapy import signals



class GuahaoSpider(scrapy.Spider):
    name = "guahao14"
    allowed_domains = ["www.guahao.com"]

    start_urls = pickle.load( open( "hospitals_Shanghai.p", "rb" ) )
    
    
    def __init__(self):
        self.total1=0
        self.total2=0
        self.urls=[]
        self.urls1=[]
        self.urls2=[]
        dispatcher.connect(self.spider_closed, signals.spider_closed)

    def parse(self, response):      
        review_url=response.xpath("//div[@class='more']/a/@href").extract_first()
        if review_url:
            self.urls.append(review_url)
            self.urls1.append(response.url)
            self.total1+=1
            print "1="+ str(self.total1)
            
        else:
            print "No reviews!"
            self.urls2.append(response.url)
            self.total2+=1
            print "2="+ str(self.total2)
        
    
    
    def spider_closed(self, spider):
        if spider is not self:
            return
        
        with open('111.p', 'wb') as f:                           
            pickle.dump(self.urls, f)    
            
        with open('112.p', 'wb') as f:                           
            pickle.dump(self.urls1, f)
        
        with open('113.p', 'wb') as f:                           
            pickle.dump(self.urls2, f)
    
    
    
                
            
            
            
            
            
            
            
            
            
            
               
    
        
        
