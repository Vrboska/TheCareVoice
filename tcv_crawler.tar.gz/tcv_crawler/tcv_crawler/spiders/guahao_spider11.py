### Scrapy spider to scrape Shanghai hospital websites from guahao.com (by Andrej Zubal)



import scrapy
import logging
import time
import pickle
from selenium import webdriver

############## this part of code is only for making selenium run with firefox on my computer

from selenium.webdriver.common.desired_capabilities import DesiredCapabilities

caps = DesiredCapabilities.FIREFOX
caps["marionette"] = True
caps["binary"] = "/usr/bin/firefox"

#############################################################################################
class GuahaoSpider(scrapy.Spider):
    name = "guahao11"
    allowed_domains = ["www.guahao.com"]

    start_urls = (
        "http://www.guahao.com/hospital/areahospitals?q=&pi=2&p=%E4%B8%8A%E6%B5%B7",
    )
    

    def __init__(self):
        
        self.driver = webdriver.Firefox()                               #defining a browser
        self.num_pages=30                                               #number of pages to crawl  in total (e.g. for Shanghai there are 30 pages)
        self.pageNo=1                                                   #current page the spider is on
        self.total=0

        self.urls=[]
    

    def parse(self, response):

        if self.pageNo<=self.num_pages:                              #going over all of the pages
            print self.pageNo
            driver = webdriver.PhantomJS()
            driver.get(response)

            div = driver.find_elements_by_xpath("//div[@id='g-cfg']//ul[@class='hos_ul']//a[@class='cover-bg']")

            for element in div:                                         #saving urls in a list 
                self.total+=1
                self.urls.append(element.get_attribute('href'))
                print self.total
            if(self.pageNo<self.num_pages):                             # this if command is here to click on the next page button using Selenium
                
                elem=driver.find_element_by_xpath("//div[@class='pagers']/a[@class='next J_pageNext_gh']")

                if (elem and elem.is_displayed()==True and elem.is_enabled()==True):
        
                    try:
                        elem.click()
                        time.sleep(5)
                        url=driver.current_url
                        self.pageNo +=1
                        yield scrapy.Request(url, callback=self.parse)

                        #WebDriverWait(self.driver, 20).until(EC.presence_of_element_located(self.driver.find_element_by_xpath("//div[@class='pagers']/a[@class='next J_pageNext_gh']")))
                        
                    except:
                        print "The next page was clicked unsuccessfully!"
                        driver.close()
                        return
                else:
                     print "Next page is either disabled or not displayed"
                     driver.close()
                     return

            
         


        
                                                    #closing the browser

        with open('hospitals.p', 'wb') as f:                            #saving the list of urls
            pickle.dump(self.urls, f)

        
