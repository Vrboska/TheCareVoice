### Scrapy spider to crawl Shanghai hospital reviews from guahao.com (by Andrej Zubal) (Sequential order with login)(works!)
### I also have a code for non-sequential order and I tested both of them, this one seems faster and more effective.
import scrapy
import logging
import time
import pickle
from selenium import webdriver
from tcv_crawler.items import  HospitalReviewItem, HospitalItem


############## this part of code is only for making selenium run with firefox on my computer

from selenium.webdriver.common.desired_capabilities import DesiredCapabilities

caps = DesiredCapabilities.FIREFOX
caps["marionette"] = True
caps["binary"] = "/usr/bin/firefox"

#############################################################################################

class GuahaoSpider(scrapy.Spider):
    name = "guahao19"
    allowed_domains = ["www.guahao.com"]

    start_urls = (
        "http://www.guahao.com/user/login", 
    )
    urls=pickle.load( open( "A.p", "rb" ) )                #urls of hospital review pages, overall 162 of them (rest of Shanghai hospitals don't have any reviews)
    login="13524005993"
    password="Zdravie"
    
    start_hosp=0                                          #the index in "urls" of the hospital where we want to start the crawl
    page=1                                                 #indicates the the order of the hospital currently scraped e.g.1 for the 1st hospital, 2 for 2nd, 3 for 3rd etc.
    total_page=30                                          #indicates the total number of hospitals to crawl
    
    total=0                                                #just an auxiliary variable counting the total number of pages crawled
    

 ###############################################################################################################################################################   
    """logging in part: following part of the code is used to login to guahao.com with login details from above (i.e. self.login and self.password)
                        the method used is 'selenium webdriver' and the login is manual
    """    
    def parse(self, response):
        driver = webdriver.Firefox()                                                                                    #opening browser
        driver.get(response.url)                                                                                        
        driver.find_element_by_id("loginId").send_keys(self.login)                                                      
        driver.find_element_by_id("password").send_keys(self.password)
        driver.find_element_by_id("validCode").send_keys(raw_input("Please enter the expression on the picture: "))     #copying the captcha and sending it to the browser, please write the captcha inside the terminal
        driver.find_element_by_id("J_LoginSubmit").click()                                                              #clicking the login button
        time.sleep(15)
        
        print driver.current_url
        yield scrapy.Request(driver.current_url, callback=self.check_login_response, cookies=driver.get_cookies())      #important is to inherit the cookies from the logged in page
        
        try:                                                                                                            #just logging out and closing the driver...
            driver.find_element_by_xpath("//*[@id='gh']/div[1]/div/div[1]/a[4]").click()
            print "Logged out successfully!"
        except:
            print "Could not log out!"
             
        driver.close()
    
        
    def check_login_response(self, response):                                                                           #checking for successful login ("Andrej" just an illustration)
        """Check the response returned by a login request to see if we are
        successfully logged in.
        """
        
        if "Andrej" in response.body:
            yield scrapy.Request(self.urls[self.start_hosp], callback=self.parse_item, dont_filter = True)
                
        else:
            self.log("bad times :(, could not log in")
 
 ### End of the logging in part 
 ########################################################################################################################################################       

 ###Start of the crawling part

    def parse_item(self, response):
        num_pages=5                                                         #number of pages to crawl  in current hospital (i.e. set as a fixed number or by some rule linked to response)
        pageNo=1                                                            #current page the spider is on
       
        request = scrapy.Request(response.url, callback=self.crawl_page,  dont_filter = True) #request to crawl the current page
        request.meta['pageNo'] = pageNo
        request.meta['num_pages'] =num_pages
        request.meta['start_url'] =response.url

        yield request 

    def crawl_page(self, response):
        review=(response.xpath("//*[@id='comment-list']/li[1]/div[@class='row-2']/div[@class='info']/p/span[1]").extract_first()) #searching for relevant content(or checking if the page loaded correctly)
        if review: 
            #the crawling part (extract the content into items here!)
            self.total+=1
            print "            "+review
            print str(self.page+self.start_hosp)+":  "+str(response.meta['pageNo'])  
            print self.total                
            
           
            if (response.meta['pageNo']<response.meta['num_pages']):
                #after the content is extracted look for the next page and call the request on the next page with the meta variables adjusted
                request = scrapy.FormRequest.from_response(
                            response,
                            formname='qPagerForm', 
                            formdata={'pageNo': str(response.meta['pageNo']+1),
                                      },
                            callback=self.crawl_page, 
                            method='POST'
                        )
                request.meta['pageNo'] = response.meta['pageNo']+1
                request.meta['num_pages'] =response.meta['num_pages']
                request.meta['start_url'] =response.meta['start_url']
                yield request 
                    
                """manual method   
                new_page=response.meta['start_url']+"?pageNo="+str(response.meta['pageNo']+1)+"&sign="+response.xpath("/html/body/div[1]/div[2]/div/div[2]/div/div/section/div[2]/div[2]/div/form/input[2]/@value").extract()[0]+"&timestamp="+response.xpath("/html/body/div[1]/div[2]/div/div[2]/div/div/section/div[2]/div[2]/div/form/input[3]/@value").extract_first()
                request = scrapy.Request(new_page, callback=self.crawl_page)
                request.meta['pageNo'] = response.meta['pageNo']+1
                request.meta['num_pages'] =response.meta['num_pages']
                request.meta['start_url'] =response.meta['start_url']
                yield request 
                """
            else:
                #if there are no more pages to crawl for the current hospital, switch to the next hospital   
                if self.page<self.total_page:
                    print "Crawled hospital "+str(self.page+self.start_hosp)+". Moving to the next hospital."
                    self.page+=1
                    request = scrapy.Request(self.urls[self.start_hosp+self.page-1], callback=self.parse_item)
                    yield request
                else:
                    #if there are no more hospitals to crawl, return   
                    print "Crawled all of them!"
                    return
        else:
            print "Couldnt read it, quitting!"
            return
        
            
            
            
            
            
