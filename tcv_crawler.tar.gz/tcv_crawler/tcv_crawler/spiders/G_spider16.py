### Scrapy spider to crawl Shanghai hospital reviews from guahao.com (by Andrej Zubal) (funguje!)
import scrapy
import logging
import time
from selenium import webdriver
from tcv_crawler.items import  HospitalReviewItem, HospitalItem


############## this part of code is only for making selenium run with firefox on my computer

from selenium.webdriver.common.desired_capabilities import DesiredCapabilities

caps = DesiredCapabilities.FIREFOX
caps["marionette"] = True
caps["binary"] = "/usr/bin/firefox"

#############################################################################################

class GuahaoSpider(scrapy.Spider):
    name = "guahao16"
    allowed_domains = ["www.guahao.com"]

    start_urls = (
        "http://www.guahao.com/user/login", 
    )
    urls=(
    "http://www.guahao.com/commentslist/h-125336070937502000/1-0", 
    )
    
    login="13524005993"
    password="Zdravie"
    total=0
    

        
    def parse(self, response):
        driver = webdriver.Firefox()
        driver.get(response.url)
        driver.find_element_by_id("loginId").send_keys(self.login)
        driver.find_element_by_id("password").send_keys(self.password)
        driver.find_element_by_id("validCode").send_keys(raw_input("Please enter the expression on the picture: "))
        driver.find_element_by_id("J_LoginSubmit").click()
        time.sleep(5)
        
        print driver.current_url
        yield scrapy.Request(driver.current_url, callback=self.check_login_response, cookies=driver.get_cookies())
        
        try:
            driver.find_element_by_xpath("//*[@id='gh']/div[1]/div/div[1]/a[4]").click()
            print "Logged out successfully!"
        except:
            print "Could not log out!"
             
        driver.close()
        
        
    def check_login_response(self, response):
        """Check the response returned by a login request to see if we are
        successfully logged in.
        """
        
        if "Andrej" in response.body:
            for url in self.urls:
                yield scrapy.Request(url, callback=self.parse_item, dont_filter = True)
                
        else:
            self.log("bad times :(, could not log in")
        
        

    def parse_item(self, response):
        num_pages=30  #number of pages to crawl  in total (i.e. set as a fixed number or by some rule linked to response)
        pageNo=1       #current page the spider is on
       
        request = scrapy.Request(response.url, callback=self.crawl_page,  dont_filter = True)
        request.meta['pageNo'] = pageNo
        request.meta['num_pages'] =num_pages
        request.meta['start_url'] =response.url

        yield request 

    def crawl_page(self, response):
        if (response.meta['pageNo']<=response.meta['num_pages']):
            print "            "+(response.xpath("//*[@id='comment-list']/li[1]/div[@class='row-2']/div[@class='info']/p/span[1]").extract_first())
            self.total+=1
            print self.total
            
            if (response.meta['pageNo']<response.meta['num_pages']):
                new_page=response.meta['start_url']+"?pageNo="+str(response.meta['pageNo']+1)+"&sign="+response.xpath("/html/body/div[1]/div[2]/div/div[2]/div/div/section/div[2]/div[2]/div/form/input[2]/@value").extract()[0]+"&timestamp="+response.xpath("/html/body/div[1]/div[2]/div/div[2]/div/div/section/div[2]/div[2]/div/form/input[3]/@value").extract_first()
                request = scrapy.Request(new_page, callback=self.crawl_page, dont_filter = True)
                request.meta['pageNo'] = response.meta['pageNo']+1
                request.meta['num_pages'] =response.meta['num_pages']
                request.meta['start_url'] =response.meta['start_url']
                yield request 
                
            else:
                print "No more pages to crawl"
                return
            
            
            
            
            
            
