### Scrapy spider to crawl Shanghai hospital reviews from guahao.com in a sequential order(by Andrej Zubal) (funguje!)
import scrapy
import logging
import time
import pickle
from tcv_crawler.items import  HospitalReviewItem, HospitalItem


class GuahaoSpider(scrapy.Spider):
    name = "guahao15"
    allowed_domains = ["www.guahao.com"]

    start_urls = (
    "http://www.guahao.com/commentslist/h-125336754304601000/1-0", 
    )
    
    total=0


        

    def parse(self, response):
        num_pages=5  #number of pages to crawl  in total (i.e. set as a fixed number or by some rule linked to response)
        pageNo=1       #current page the spider is on
       
        request = scrapy.Request(response.url, callback=self.crawl_page, dont_filter = True)
        request.meta['pageNo'] = pageNo
        request.meta['num_pages'] =num_pages
        request.meta['start_url'] =response.url

        yield request 
    
        
    def crawl_page(self, response):
        review=(response.xpath("//*[@id='comment-list']/li[1]/div[@class='row-2']/div[@class='info']/p/span[1]").extract_first()) #searching for relevant content(or checking if the page loaded correctly)
        if review: 
            #the crawling part (extract the content into items here!)
            self.total+=1
            print "            "+review
            print response.url+":  "+str(response.meta['pageNo'])  
            print self.total                
            
            if (response.meta['pageNo']<response.meta['num_pages']):
                
                """
                new_page=response.meta['start_url']+"?pageNo="+str(response.meta['pageNo']+1)+"&sign="+response.xpath("/html/body/div[1]/div[2]/div/div[2]/div/div/section/div[2]/div[2]/div/form/input[2]/@value").extract()[0]+"&timestamp="+response.xpath("/html/body/div[1]/div[2]/div/div[2]/div/div/section/div[2]/div[2]/div/form/input[3]/@value").extract_first()
                request = scrapy.Request(new_page, callback=self.crawl_page)
                request.meta['pageNo'] = response.meta['pageNo']+1
                request.meta['num_pages'] =response.meta['num_pages']
                request.meta['start_url'] =response.meta['start_url']
                yield request 
                """
                request = scrapy.FormRequest.from_response(
                            response,
                            formname='qPagerForm', 
                            formdata={'pageNo': str(response.meta['pageNo']+1),
                                      #'sign': response.xpath("/html/body/div[1]/div[2]/div/div[2]/div/div/section/div[2]/div[2]/div/form/input[2]/@value").extract()[0], 
                                      #'timestamp': response.xpath("/html/body/div[1]/div[2]/div/div[2]/div/div/section/div[2]/div[2]/div/form/input[3]/@value").extract_first(),
                                      #'action': 'http://www.guahao.com/commentslist/h-125336754304601000/1-0',  
                                      },
                            callback=self.crawl_page, 
                            dont_filter = True, 
                            method='POST'
                        )
                request.meta['pageNo'] = response.meta['pageNo']+1
                request.meta['num_pages'] =response.meta['num_pages']
                request.meta['start_url'] =response.meta['start_url']
                #request._set_url('http://www.guahao.com/commentslist/h-125336754304601000/1-0')
                yield request 
            else: 
                print "Couldnt find it, quitting"
                return
                    
                    
                
                
            
            
            
            
