import scrapy
import logging
import webbrowser
import time
from tcv_crawler.items import HospitalItem, HospitalReviewItem
from selenium import webdriver
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities

caps = DesiredCapabilities.FIREFOX

# Tell the Python bindings to use Marionette.
# This will not be necessary in the future,
# when Selenium will auto-detect what remote end
# it is talking to.
caps["marionette"] = True

# Path to Firefox DevEdition or Nightly.
# Firefox 47 (stable) is currently not supported,
# and may give you a suboptimal experience.
#
# On Mac OS you must point to the binary executable
# inside the application package, such as
# /Applications/FirefoxNightly.app/Contents/MacOS/firefox-bin
caps["binary"] = "/usr/bin/firefox"


class GuahaoSpider(scrapy.Spider):
    name = "guahao4"
    allowed_domains = ["www.guahao.com"]
    start_urls = (
        "http://www.guahao.com/commentslist/h-8f113a19-eee7-47b8-9517-2ad069a2f57a000/1-0",
    )

    def __init__(self):
        self.driver = webdriver.Firefox()


    def parse(self, response):
        self.driver.get(response.url)
        print "Andrej"
        elem=self.driver.find_element_by_xpath("//div[@class='pagers']/a[@class='next']")
        print elem.is_displayed()
        print elem.is_enabled()
        
        
        try:
            elem.click()
            print self.driver.current_url
        except:
            print "The next page was clicked unsuccessfully!"
        finally:self.driver.close()

