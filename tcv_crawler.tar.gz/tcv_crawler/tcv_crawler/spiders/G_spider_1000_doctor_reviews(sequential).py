### Scrapy spider to crawl Shanghai doctors and extract their info and reviews from guahao.com (by Andrej Zubal) (works sequentially for only one hospital at a time!)
import scrapy
import time
import pickle
from scrapy.loader import ItemLoader
from tcv_crawler.items import PhysicianReviewItem,  PhysicianItem


class GuahaoSpider(scrapy.Spider):
    name = "guahaoDoct1000s"
    allowed_domains = ["www.guahao.com"]

    #start_urls = ("http://www.guahao.com/user/login", )
    start_urls=pickle.load( open( "hospitals_Shanghai.p", "rb" ) )[10:11]
    urls=pickle.load( open( "hospitals_Shanghai.p", "rb" ) )
    
    total=0
    total_comment=0
    doctorIDs=set()
    total_hosp=10
    start_hosp=11
    
    def parse(self, response):
        print response.url[31:]
        
        request=scrapy.Request(response.url,  callback=self.hospital_page)
        request.meta['hospital_page']=self.start_hosp
        yield request
        
    def hospital_page(self, response):
        hospital_name=response.xpath("//div[@class='detail word-break']/h1/strong/a/text()").extract_first()
        hospitalID=response.url[31:]
        
        department_urls = map(lambda x: x.strip(' \r\n\t'), response.xpath("//div[@class='grid-content']//a[@class='ishao']/@href").extract())
        department_total=min(10, len(department_urls))
        
        

        #print(list(department_urls))        
        request = scrapy.Request(department_urls[0], callback=self.department_page,  dont_filter=True)
        request.meta['department_page'] = 1
        request.meta['hospitalID']=hospitalID
        request.meta['hospital_name']=hospital_name
        request.meta['department_total']=department_total
        request.meta['department_urls']=department_urls
        request.meta['hospital_page']=response.meta['hospital_page']
        
        yield request
            
    def department_page(self, response):
        department_name = response.xpath("//div[@class='department-left']/h1/text()").extract()[0]
        doctor_urls = response.xpath("//div[@id='anchor']//dt/a/@href").extract()

        request = scrapy.Request(doctor_urls[0], callback=self.doctor_page, dont_filter=True)
        request.meta['department_name'] = department_name
        request.meta['department_page']=response.meta['department_page']
        request.meta['doctor_urls']=doctor_urls
        request.meta['doctor_page'] = 1
        request.meta['doctor_total'] = len(doctor_urls)
        request.meta['hospitalID']=response.meta['hospitalID']
        request.meta['hospital_name']=response.meta['hospital_name']
        request.meta['department_total']=response.meta['department_total']
        request.meta['department_urls']=response.meta['department_urls']
        request.meta['hospital_page']=response.meta['hospital_page']

        



        yield request        
        
    def doctor_page(self, response):
        
        doctor_ID=response.xpath("//meta[@name='adsKeywords']/@content").extract_first().strip('hid:,did:,eid:')
        doctor_photo = 'http:' + response.xpath("//div[@class='info']//div[@class='summary']//img[@class='photo']//@src").extract()[0]
        doctor_name = response.xpath("//div[@class='info']//h1/strong/text()").extract()
        doctor_level = response.xpath("//div[@class='info']//h1/span/text()").extract()
        doctor_speciality = response.xpath("//div[@class='info']//div[@class='goodat']/span/text()").extract()
        doctor_description = response.xpath("//div[@class='info']//div[@class='about']/a/@data-description").extract()
        doctor_rating=response.xpath("//div[@class='data']/div[@id='expert-rate']/a/strong/text()").extract_first()        
        
        l = ItemLoader(item=PhysicianItem(), response=response)        
        l.add_value('hospitalID', response.meta['hospitalID'])
        l.add_value('hospital_name', response.meta['hospital_name'])
        l.add_value('department_name', response.meta['department_name'])
        l.add_value('ID', doctor_ID)
        l.add_value('name', doctor_name)
        l.add_value('photo', doctor_photo)
        l.add_value('level', doctor_level)
        l.add_value('speciality', doctor_speciality)
        l.add_value('description', doctor_description)
        l.add_value('rating', doctor_rating)

        yield l.load_item()
        
        self.total+=1
        print doctor_ID+"   :doctor number "+str(self.total)
    
        
        if doctor_ID not in self.doctorIDs:
            self.doctorIDs.add(doctor_ID)
            comment_url=response.xpath("//div[@class='grid-content']/div[@class='more']/a/@href").extract_first()
            if comment_url:
                request=scrapy.Request(comment_url, callback=self.comment_page,  dont_filter=True)
                request.meta['doctor_name'] = doctor_name
                request.meta['doctorID'] = doctor_ID
                request.meta['department_name'] = response.meta['department_name']
                request.meta['department_page']=response.meta['department_page']
                request.meta['doctor_urls']=response.meta['doctor_urls']
                request.meta['doctor_page'] = response.meta['doctor_page']
                request.meta['doctor_total'] = response.meta['doctor_total']
                request.meta['hospitalID']=response.meta['hospitalID']
                request.meta['hospital_name']=response.meta['hospital_name']
                request.meta['department_total']=response.meta['department_total']
                request.meta['department_urls']=response.meta['department_urls']
                request.meta['hospital_page']=response.meta['hospital_page']

                yield request

            else:
                print "No comments for this doctor!"
                if response.meta['doctor_page']<response.meta['doctor_total'] :
                    request = scrapy.Request(response.meta['doctor_urls'][response.meta['doctor_page']], callback=self.doctor_page, dont_filter=True)
                    request.meta['department_name'] = response.meta['department_name']
                    request.meta['department_page']=response.meta['department_page']
                    request.meta['doctor_urls']=response.meta['doctor_urls']
                    request.meta['doctor_page'] = response.meta['doctor_page']+1
                    request.meta['doctor_total'] = response.meta['doctor_total']
                    request.meta['hospitalID']=response.meta['hospitalID']
                    request.meta['hospital_name']=response.meta['hospital_name']
                    request.meta['department_total']=response.meta['department_total']
                    request.meta['department_urls']=response.meta['department_urls']
                    request.meta['hospital_page']=response.meta['hospital_page']

                    yield request
                elif response.meta['department_page']<response.meta['department_total']:
                    print "Finished this department"
                    request = scrapy.Request(response.meta['department_urls'][response.meta['department_page']], callback=self.department_page,  dont_filter=True)
                    request.meta['department_page'] = response.meta['department_page']+1
                    request.meta['hospitalID']=response.meta['hospitalID']
                    request.meta['hospital_name']=response.meta['hospital_name']
                    request.meta['department_total']=response.meta['department_total']
                    request.meta['department_urls']=response.meta['department_urls']
                    request.meta['hospital_page']=response.meta['hospital_page']                   
                    yield request
                    
                elif response.meta['hospital_page']<self.start_hosp+self.total_hosp-1:
                    print "Finished this hospital!"
                    request = scrapy.Request(self.urls[response.meta['hospital_page']], callback=self.hospital_page)
                    request.meta['hospital_page']=response.meta['hospital_page']+1
                    yield request
                    
                else:
                    print "All hospitals departments and doctors are done!"
                    return
                        

        else: 
            print "We already have this doctor's comments"
            if response.meta['doctor_page']<response.meta['doctor_total'] :
                request = scrapy.Request(response.meta['doctor_urls'][response.meta['doctor_page']], callback=self.doctor_page, dont_filter=True)
                request.meta['department_name'] = response.meta['department_name']
                request.meta['department_page']=response.meta['department_page']
                request.meta['doctor_urls']=response.meta['doctor_urls']
                request.meta['doctor_page'] = response.meta['doctor_page']+1
                request.meta['doctor_total'] = response.meta['doctor_total']
                request.meta['hospitalID']=response.meta['hospitalID']
                request.meta['hospital_name']=response.meta['hospital_name']
                request.meta['department_total']=response.meta['department_total']
                request.meta['department_urls']=response.meta['department_urls']
                request.meta['hospital_page']=response.meta['hospital_page']

                yield request
            elif response.meta['department_page']<response.meta['department_total']:
                print "Finished this department"
                request = scrapy.Request(response.meta['department_urls'][response.meta['department_page']], callback=self.department_page,  dont_filter = True)
                request.meta['department_page'] = response.meta['department_page']+1
                request.meta['hospitalID']=response.meta['hospitalID']
                request.meta['hospital_name']=response.meta['hospital_name']
                request.meta['department_total']=response.meta['department_total']
                request.meta['department_urls']=response.meta['department_urls']
                request.meta['hospital_page']=response.meta['hospital_page']                   
                yield request
                
            elif response.meta['hospital_page']<self.start_hosp+self.total_hosp-1:
                print "Finished this hospital!"
                request = scrapy.Request(self.urls[response.meta['hospital_page']], callback=self.hospital_page)
                request.meta['hospital_page']=response.meta['hospital_page']+1
                yield request
                
            else:
                print "All hospitals departments and doctors are done!"
                return
                

    
            
    def comment_page(self, response):
        pages=response.xpath("//form[@name='qPagerForm']/div[@class='other-info']/span[1]/label/text()").extract_first()
        if pages==None:
            pages=1
        else:
            pages=int(pages)
            
        num_pages=min(5, pages)
                                                         #number of pages to crawl  in current hospital (i.e. set as a fixed number or by some rule linked to response)
        pageNo=1                                                            #current page the spider is on
       
        request = scrapy.Request(response.url, callback=self.crawl_page, dont_filter = True) #request to crawl the current page
        request.meta['pageNo'] = pageNo
        request.meta['num_pages'] =num_pages
        request.meta['doctor_name'] = response.meta['doctor_name']
        request.meta['doctorID'] =response.meta['doctorID']
        request.meta['department_name'] = response.meta['department_name']
        request.meta['department_page']=response.meta['department_page']
        request.meta['doctor_urls']=response.meta['doctor_urls']
        request.meta['doctor_page'] = response.meta['doctor_page']
        request.meta['doctor_total'] = response.meta['doctor_total']
        request.meta['hospitalID']=response.meta['hospitalID']
        request.meta['hospital_name']=response.meta['hospital_name']
        request.meta['department_total']=response.meta['department_total']
        request.meta['department_urls']=response.meta['department_urls']
        request.meta['hospital_page']=response.meta['hospital_page']
        
        yield request 



    def crawl_page(self, response):
        review=(response.xpath("//*[@id='comment-list']/li[1]/div[@class='row-2']/div[@class='info']/p/span[1]").extract_first()) #searching for relevant content(or checking if the page loaded correctly)
        if review: 
            #the crawling part (extract the content into items here!)
            
            hospitalID=response.meta['hospitalID']
            doctorID=response.meta['doctorID']
            doctor_name=response.meta['doctor_name']



            reviewers=response.xpath("//ul[@class='word-wrap list']/li/div[@class='user']/p/text()").extract()
            reviewers=map(lambda x: x.strip('        \r\n\t'), reviewers)
            
            texts= response.xpath("//ul[@class='word-wrap list']/li/div[@class='row-2']/div[@class='text']/span[@class='summary']/text()").extract()
            
            times=map(lambda x: x[:20],(response.xpath("//ul[@class='word-wrap list']/li/div[@class='row-2']/div[@class='info']/p/span[1]/text()").extract()))
    
            
            #diseases= response.xpath("//ul[@class='word-wrap list']/li/div[@class='row-1']/p[@class='disease']/span[1]/text()").extract()
    
            
            
            
            for i in range(len(reviewers)):
                l = ItemLoader(item=PhysicianReviewItem(), response=response)
                l.add_value('doctor_name', doctor_name)
                l.add_value('hospitalID', hospitalID)
                l.add_value('doctorID', doctorID)

                l.add_value('reviewer', reviewers[i-1])
                l.add_value('text', texts[i-1])
                l.add_value('time', times[i-1])
                #l.add_value('disease', diseases[i-1])
    
                yield l.load_item()        
                self.total_comment+=1
                print self.total_comment 
        
            if (response.meta['pageNo']<response.meta['num_pages']):
                #after the content is extracted look for the next page and call the request on the next page with the meta variables adjusted
                new_page="http://www.guahao.com/commentslist/e-"+doctorID+"/all-0?"+"pageNo="+str(response.meta['pageNo']+1)+"&sign="+ response.xpath("//form[@name='qPagerForm']/input[@name='sign']/@value").extract()[0]+"&timestamp="+ response.xpath("//form[@name='qPagerForm']/input[@name='timestamp']/@value").extract_first()

                request = scrapy.Request(new_page, callback=self.crawl_page, dont_filter = True)

                request.meta['pageNo'] = response.meta['pageNo']+1
                request.meta['num_pages'] =response.meta['num_pages']
                request.meta['doctor_name'] = response.meta['doctor_name']
                request.meta['doctorID'] =response.meta['doctorID']
                request.meta['department_name'] = response.meta['department_name']
                request.meta['department_page']=response.meta['department_page']
                request.meta['doctor_urls']=response.meta['doctor_urls']
                request.meta['doctor_page'] = response.meta['doctor_page']
                request.meta['doctor_total'] = response.meta['doctor_total']
                request.meta['hospitalID']=response.meta['hospitalID']
                request.meta['hospital_name']=response.meta['hospital_name']
                request.meta['department_total']=response.meta['department_total']
                request.meta['department_urls']=response.meta['department_urls']
                request.meta['hospital_page']=response.meta['hospital_page']

                yield request 
            else:
                print "Finished scraping this doctor"
                if response.meta['doctor_page']<response.meta['doctor_total'] :
                    request = scrapy.Request(response.meta['doctor_urls'][response.meta['doctor_page']], callback=self.doctor_page, dont_filter=True)
                    request.meta['department_name'] = response.meta['department_name']
                    request.meta['department_page']=response.meta['department_page']
                    request.meta['doctor_urls']=response.meta['doctor_urls']
                    request.meta['doctor_page'] = response.meta['doctor_page']+1
                    request.meta['doctor_total'] = response.meta['doctor_total']  
                    request.meta['hospitalID']=response.meta['hospitalID']
                    request.meta['hospital_name']=response.meta['hospital_name']
                    request.meta['department_total']=response.meta['department_total']
                    request.meta['department_urls']=response.meta['department_urls']
                    request.meta['hospital_page']=response.meta['hospital_page']
                    yield request
                elif response.meta['department_page']<response.meta['department_total']:
                    print "Finished this department"
                    request = scrapy.Request(response.meta['department_urls'][response.meta['department_page']], callback=self.department_page,  dont_filter = True)
                    request.meta['department_page'] = response.meta['department_page']+1
                    request.meta['hospitalID']=response.meta['hospitalID']
                    request.meta['hospital_name']=response.meta['hospital_name']
                    request.meta['department_total']=response.meta['department_total']
                    request.meta['department_urls']=response.meta['department_urls']
                    request.meta['hospital_page']=response.meta['hospital_page']                   
                    yield request
                    
                elif response.meta['hospital_page']<self.start_hosp+self.total_hosp-1:
                    print "Finished this hospital!"
                    request = scrapy.Request(self.urls[response.meta['hospital_page']], callback=self.hospital_page)
                    request.meta['hospital_page']=response.meta['hospital_page']+1
                    yield request

                else:
                    print "All hospitals departments and doctors are done!"
                    return
        else:
            
            print "Cannot open this page, moving to next doctor!"
            if response.meta['doctor_page']<response.meta['doctor_total'] :
                request = scrapy.Request(response.meta['doctor_urls'][response.meta['doctor_page']], callback=self.doctor_page,  dont_filter=True)
                request.meta['department_name'] = response.meta['department_name']
                request.meta['department_page']=response.meta['department_page']
                request.meta['doctor_urls']=response.meta['doctor_urls']
                request.meta['doctor_page'] = response.meta['doctor_page']+1
                request.meta['doctor_total'] = response.meta['doctor_total']
                request.meta['hospitalID']=response.meta['hospitalID']
                request.meta['hospital_name']=response.meta['hospital_name']
                request.meta['department_total']=response.meta['department_total']
                request.meta['department_urls']=response.meta['department_urls']
                request.meta['hospital_page']=response.meta['hospital_page']

                yield request
            elif response.meta['department_page']<response.meta['department_total']:
                print "Finished this department"
                request = scrapy.Request(response.meta['department_urls'][response.meta['department_page']], callback=self.department_page,  dont_filter = True)
                request.meta['department_page'] = response.meta['department_page']+1
                request.meta['hospitalID']=response.meta['hospitalID']
                request.meta['hospital_name']=response.meta['hospital_name']
                request.meta['department_total']=response.meta['department_total']
                request.meta['department_urls']=response.meta['department_urls']
                request.meta['hospital_page']=response.meta['hospital_page']                   
                yield request
                
            elif response.meta['hospital_page']<self.start_hosp+self.total_hosp-1:
                print "Finished this hospital!"
                request = scrapy.Request(self.urls[response.meta['hospital_page']], callback=self.hospital_page)
                request.meta['hospital_page']=response.meta['hospital_page']+1
                yield request
            else:
                print "All hospitals departments and doctors are done!"
                return
            return
            
        
       
   
            
            
    
        

