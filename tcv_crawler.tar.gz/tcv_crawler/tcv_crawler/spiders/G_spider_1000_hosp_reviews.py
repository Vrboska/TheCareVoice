### Scrapy spider to crawl Shanghai hospitas and extract their info from guahao.com (by Andrej Zubal) (funguje!)
import scrapy
import time
import pickle
from scrapy.loader import ItemLoader
from tcv_crawler.items import HospitalReviewItem


class GuahaoSpider(scrapy.Spider):
    name = "guahaoHosp1000"
    allowed_domains = ["www.guahao.com"]

    start_urls = ("http://www.guahao.com/user/login", )
    urls=pickle.load( open( "A.p", "rb" ) ) 
    start_hosp=0                                       #the index in "urls" of the hospital where we want to start the crawl
    page=1                                                 #indicates the the order of the hospital currently scraped e.g.1 for the 1st hospital, 2 for 2nd, 3 for 3rd etc.
    total_page=50                                          #indicates the total number of hospitals to crawl
    
    total=0                                                #just an auxiliary variable counting the total number of reviews scraped
    
    
    def parse(self, response):
        yield scrapy.Request(self.urls[self.start_hosp], callback=self.parse_item, dont_filter = True)

    def parse_item(self, response):
        print response.url[37:][:-4]
        hospital_name=response.xpath("//div[@class='detail word-break']/h1/strong/a/text()").extract_first()
        hospitalID=response.url[37:][:-4]
        
        pages=response.xpath("//form[@name='qPagerForm']/div[@class='other-info']/span[1]/label/text()").extract_first()
        if pages==None:
            pages=1
        else:
            pages=int(pages)
            
        num_pages=min(5, pages)
                                                         #number of pages to crawl  in current hospital (i.e. set as a fixed number or by some rule linked to response)
        pageNo=1                                                            #current page the spider is on
       
        request = scrapy.Request(response.url, callback=self.crawl_page,  dont_filter = True) #request to crawl the current page
        request.meta['pageNo'] = pageNo
        request.meta['num_pages'] =num_pages
        request.meta['start_url'] =response.url
        request.meta['hospital_name'] =hospital_name
        request.meta['hospitalID'] =hospitalID
        yield request 



    def crawl_page(self, response):
        review=(response.xpath("//*[@id='comment-list']/li[1]/div[@class='row-2']/div[@class='info']/p/span[1]").extract_first()) #searching for relevant content(or checking if the page loaded correctly)
        if review: 
            #the crawling part (extract the content into items here!)
            
            hospital_name=response.meta['hospital_name']
            hospitalID=response.meta['hospitalID']
            reviewers=response.xpath("//ul[@class='word-wrap list']/li/div[@class='user']/p/text()").extract()
            reviewers=map(lambda x: x.strip('        \r\n\t'), reviewers)
            
            texts= response.xpath("//ul[@class='word-wrap list']/li/div[@class='row-2']/div[@class='text']/span[@class='summary']/text()").extract()
            
            times=map(lambda x: x[:19],(response.xpath("//ul[@class='word-wrap list']/li/div[@class='row-2']/div[@class='info']/p/span[1]/text()").extract()))
    
            
            diseases= response.xpath("//ul[@class='word-wrap list']/li/div[@class='row-1']/p[@class='disease']/span[1]/text()").extract()
    
            
            satisfactions=response.xpath("//ul[@class='word-wrap list']/li/div[@class='row-1']/p[@class='effect']/strong[1]/text()").extract()
            satisfactions=map(lambda x: x.strip('        \r\n\t'), satisfactions)
    
            
            doctorIDs=map(lambda x: x[29:], response.xpath("//ul[@class='word-wrap list']/li/div[@class='row-2']/div[@class='info']/p[1]/span[2]/a/@href").extract())
            
            for i in range(len(reviewers)):
                l = ItemLoader(item=HospitalReviewItem(), response=response)
                l.add_value('hospital_name', hospital_name)
                l.add_value('hospitalID', hospitalID)
                l.add_value('reviewer', reviewers[i-1])
                l.add_value('text', texts[i-1])
                l.add_value('time', times[i-1])
                l.add_value('disease', diseases[i-1])
                l.add_value('satisfaction', satisfactions[i-1])
                l.add_value('doctorID', doctorIDs[i-1])
    
                yield l.load_item()
                self.total+=1
                print self.total
                
                  

            print str(self.page+self.start_hosp)+":  "+str(response.meta['pageNo'])

            
           
            if (response.meta['pageNo']<response.meta['num_pages']):
                #after the content is extracted look for the next page and call the request on the next page with the meta variables adjusted
                request = scrapy.FormRequest.from_response(
                            response,
                            formname='qPagerForm', 
                            formdata={'pageNo': str(response.meta['pageNo']+1),
                                      },
                            callback=self.crawl_page, 
                            method='POST'
                        )
                request.meta['pageNo'] = response.meta['pageNo']+1
                request.meta['num_pages'] =response.meta['num_pages']
                request.meta['start_url'] =response.meta['start_url']
                request.meta['hospital_name'] =response.meta['hospital_name']
                request.meta['hospitalID'] =response.meta['hospitalID']
                yield request 
                    
                """manual method   
                new_page=response.meta['start_url']+"?pageNo="+str(response.meta['pageNo']+1)+"&sign="+response.xpath("/html/body/div[1]/div[2]/div/div[2]/div/div/section/div[2]/div[2]/div/form/input[2]/@value").extract()[0]+"&timestamp="+response.xpath("/html/body/div[1]/div[2]/div/div[2]/div/div/section/div[2]/div[2]/div/form/input[3]/@value").extract_first()
                request = scrapy.Request(new_page, callback=self.crawl_page)
                request.meta['pageNo'] = response.meta['pageNo']+1
                request.meta['num_pages'] =response.meta['num_pages']
                request.meta['start_url'] =response.meta['start_url']
                yield request 
                """
            else:
                #if there are no more pages to crawl for the current hospital, switch to the next hospital   
                if self.page<self.total_page:
                    print "Crawled hospital "+str(self.page+self.start_hosp)+". Moving to the next hospital."
                    self.page+=1
                    request = scrapy.Request(self.urls[self.start_hosp+self.page-1], callback=self.parse_item)
                    yield request
                else:
                    #if there are no more hospitals to crawl, return   
                    print "Crawled all of them!"
                    return
        else:
            print "Couldnt read it, quitting!"
            return
            
            
            
        
