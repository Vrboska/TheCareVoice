### Scrapy spider to crawl Shanghai hospitas and extract their info from guahao.com (by Andrej Zubal) (funguje!)
import scrapy
import time
import pickle
from scrapy.loader import ItemLoader
from tcv_crawler.items import HospitalItem


class GuahaoSpider(scrapy.Spider):
    name = "guahaoHosp"
    allowed_domains = ["www.guahao.com"]

    start_urls = pickle.load( open( "hospitals_Shanghai.p", "rb" ) )
    
    total=0                                                #just an auxiliary variable counting the total number of pages crawled


    def parse(self, response):
        print response.url[31:]
        l = ItemLoader(item=HospitalItem(), response=response)
        l.add_value('ID', response.url[31:])
        
        name=response.xpath("//div[@class='detail word-break']/h1/strong/a/text()").extract_first()
        if name:
            l.add_value('name', name)
        else: 
            self.log("bad times :(, could not find name")
            
            
        description=response.xpath("//div[@class='about']/span/text()").extract_first()
        if description:
            l.add_value('description', description)
            l.add_xpath('description', "//div[@class='about']/span/a/@href")
        else: 
            self.log("bad times :(, could not find description")
            
            
        address= response.xpath("//div[@class='address']/span/@title").extract_first()
        if address:
            l.add_value('address', address)
        else:
            self.log("bad times :(, could not find address")
 
        website= response.xpath("//div[@class='website']/span/text()").extract_first()
        if website:
            l.add_value('website', website[1:])
        else:
            print("bad times :(, could not find website")
          
          
        phone= response.xpath("//div[@class='tel']/span/text()").extract_first()
        if phone:
            l.add_value('phone', phone.strip('\r\n         '))
        else:
            print("bad times :(, could not find phone")
        
        
        level= response.xpath("//div[@class='detail word-break']/h1/span[1]/text()").extract_first()
        if level:
            l.add_value('level', level.strip('\r\n                  '))
        else:
            print("bad times :(, could not find level")
            
        
 
        yield l.load_item()
        self.total+=1
        print "Hospital "+response.url+" is done!"
        print self.total
        



   
            
            
    
        
        
