# -*- coding: utf-8 -*-
import scrapy
import logging
import webbrowser
from tcv_crawler.items import HospitalItem, PhysicianItem

class GuahaoSpider(scrapy.Spider):
    name = "guahao"
    allowed_domains = ["www.guahao.com"]
    start_urls = (
        "http://www.guahao.com/hospital/areahospitals?pi=2&p=%E4%B8%8A%E6%B5%B7",
    )

    def parse(self, response):
        urls = response.xpath("//div[@id='g-cfg']//ul[@class='hos_ul']//a[@class='cover-bg']/@href").extract()
        print("urls is", urls)
        for url in urls[0:1]:
            request = scrapy.Request(url, callback=self.hospital_page)
            yield request
        

    def hospital_page(self, response):
        hospital = HospitalItem()
        hospital_name = response.xpath("//div[@class='info']//strong/a/text()").extract()[0]
        department_names = map(lambda x: x.strip(' \r\n\t'), response.xpath("//div[@class='grid-content']//a[@class='ishao']/text()").extract())
        department_urls = map(lambda x: x.strip(' \r\n\t'), response.xpath("//div[@class='grid-content']//a[@class='ishao']/@href").extract())
        #print(list(department_urls))
        for url in department_urls[1:2]:
            request = scrapy.Request(url, callback=self.department_page)
            request.meta['hospital_name'] = hospital_name
            yield request
                  

    def department_page(self, response):
        department_name = response.xpath("//div[@class='department-left']/h1/text()").extract()[0]
        doctor_urls = response.xpath("//div[@id='anchor']//dt/a/@href").extract()
        print(department_name)
        for url in doctor_urls[0:11]:
            request = scrapy.Request(url, callback=self.doctor_page)
            request.meta['hospital_name'] = response.meta['hospital_name']
            request.meta['department_name'] = department_name
            yield request        

    def doctor_page(self, response):
        doctor_photo = 'http:' + response.xpath("//div[@class='info']//div[@class='summary']//img[@class='photo']//@src").extract()[0]
        doctor_name = response.xpath("//div[@class='info']//h1/strong/text()").extract()
        doctor_level = response.xpath("//div[@class='info']//h1/span/text()").extract()
        doctor_speciality = response.xpath("//div[@class='info']//div[@class='goodat']/span/text()").extract()
        doctor_description = response.xpath("//div[@class='info']//div[@class='about']/a/@data-description").extract()

        physician = PhysicianItem(name=doctor_name, level=doctor_level, speciality=doctor_speciality, 
            description=doctor_description, photo=doctor_photo, department=response.meta['department_name'], hospital=response.meta['hospital_name'])

        #webbrowser.open(doctor_photo)
        #print(doctor_name)
        #print(doctor_photo)
        #print(doctor_level)
        #print(doctor_speciality)
        #print(doctor_description)
        reviews_ul = response.css('ul#comment-list').css('li')
        for review_li in reviews_ul:
            review_text = review_li.css('.text .summary').xpath('text()').extract()
            review_time = review_li.css('.info').css('span').xpath('text()').extract()
            review_username = review_li.css('.user p').xpath('text()').extract()
        print(physician)


    def strip_text(self, text):
        if text:
            list(map(lambda x: x.strip(' \r\n\t'), text))
        else:
            text
        


