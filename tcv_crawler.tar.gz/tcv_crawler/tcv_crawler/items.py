
# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# http://doc.scrapy.org/en/latest/topics/items.html

import scrapy

class HospitalItem(scrapy.Item):
    # define the fields for your item here like:
    name = scrapy.Field()
    ID = scrapy.Field()#as appears in the URL
    description = scrapy.Field()
    address = scrapy.Field()
    website = scrapy.Field()
    phone = scrapy.Field()
    level = scrapy.Field()
    departments=scrapy.Field()#list of DepartmentItems//probably not necessary
    reviews=scrapy.Field()#list of all the reviews//probably not necessary

class DepartmentItem(scrapy.Item):
    # define the fields for your item here like:
    name = scrapy.Field()
    hospital=scrapy.Field()#hospital name as given in HospitalItem.name
    ID = scrapy.Field()#as appears in the URL
    description = scrapy.Field()
    address = scrapy.Field()
    website = scrapy.Field()
    phone = scrapy.Field()
    doctors=scrapy.Field()#list of PhysicianItems//probably not necessary
	


class PhysicianItem(scrapy.Item):
    # define the fields for your item here like:
    name = scrapy.Field()
    hospitalID = scrapy.Field()#ID of the hospital
    hospital_name=scrapy.Field()#name of the hospital
    ID = scrapy.Field()#as appears in the URL of the doctor
    department_name = scrapy.Field()#list of departments the physician works in
    description = scrapy.Field()
    level = scrapy.Field()
    gender = scrapy.Field()
    photo = scrapy.Field()
    speciality = scrapy.Field()
    rating = scrapy.Field()

class HospitalReviewItem(scrapy.Item):
    # define the fields for your item here like:
    reviewer = scrapy.Field()
    text=scrapy.Field()
    hospitalID = scrapy.Field()
    hospital_name=scrapy.Field()
    disease = scrapy.Field()
    time = scrapy.Field()#time of the review
    satisfaction = scrapy.Field()
    doctorID = scrapy.Field()#which doctor the reviewer visits

class PhysicianReviewItem(scrapy.Item):
    # define the fields for your item here like:
    reviewer = scrapy.Field()
    text=scrapy.Field()
    doctor_name=scrapy.Field()
    doctorID = scrapy.Field()
    hospitalID = scrapy.Field()
    disease = scrapy.Field()
    time = scrapy.Field()#time of the review
    satisfaction = scrapy.Field()
    source = scrapy.Field()#source of the treatment (either hospital or online)



